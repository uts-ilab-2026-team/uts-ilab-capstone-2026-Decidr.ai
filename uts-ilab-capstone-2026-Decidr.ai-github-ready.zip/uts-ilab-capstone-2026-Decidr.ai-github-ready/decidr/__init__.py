"""Traceable organisational claim-assessment prototype."""

__version__ = "0.0.1"

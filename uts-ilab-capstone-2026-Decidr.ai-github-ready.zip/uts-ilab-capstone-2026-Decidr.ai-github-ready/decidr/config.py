import os
from pathlib import Path

from dotenv import load_dotenv
from loguru import logger

# Paths
PROJ_ROOT = Path(__file__).resolve().parents[1]

# Load the repository's local configuration even when a command is launched from
# another working directory.
load_dotenv(PROJ_ROOT / ".env")


def _configured_path(name: str, default: Path) -> Path:
    """Resolve relative environment paths from the repository root."""
    configured = os.getenv(name)
    if not configured:
        return default.resolve()
    path = Path(configured).expanduser()
    return (PROJ_ROOT / path).resolve() if not path.is_absolute() else path.resolve()


DATA_DIR = PROJ_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
INTERIM_DATA_DIR = DATA_DIR / "interim"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
EXTERNAL_DATA_DIR = DATA_DIR / "external"

MODELS_DIR = PROJ_ROOT / "models"

# The client releases may live outside the repository. Environment variables keep
# those locations machine-specific and prevent accidental copies into version control.
DEFAULT_CLIENT_DATA_ROOT = PROJ_ROOT.parent / "Decidr Capstone Project" / "04 Data" / "01 Raw"
CLIENT_DATA_ROOT = _configured_path("DECIDR_CLIENT_DATA_ROOT", DEFAULT_CLIENT_DATA_ROOT)
PHASE1_DATA_DIR = _configured_path(
    "DECIDR_PHASE1_DATA_DIR", CLIENT_DATA_ROOT / "phase1_framework_development"
)
PHASE2_DATA_DIR = _configured_path(
    "DECIDR_PHASE2_DATA_DIR", CLIENT_DATA_ROOT / "phase2_model_development"
)
DATABASE_PATH = _configured_path("DECIDR_DATABASE_PATH", PROCESSED_DATA_DIR / "evidence.sqlite3")

REPORTS_DIR = PROJ_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"

# If tqdm is installed, configure loguru with tqdm.write
# https://github.com/Delgan/loguru/issues/135
try:
    from tqdm import tqdm

    logger.remove(0)
    logger.add(lambda msg: tqdm.write(msg, end=""), colorize=True)
except ModuleNotFoundError:
    pass

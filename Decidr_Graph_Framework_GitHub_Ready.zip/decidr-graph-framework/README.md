# Decidr standalone graph credibility framework

This is an independent graph-based credibility framework and graph facts
register. It does not import, modify or write to the ledger-based Decidr
implementation.

## Included

- Person, Role, Function, Process and System organisational backbone.
- Document and Fact nodes.
- `FORMAL` and `OBSERVED` Document-to-Fact attestations.
- Local deterministic TF-IDF Fact retrieval.
- Source, lifecycle-status and date-aware credibility scoring.
- Separate formal, observed, combined-outcome and confidence fields.
- Evidence gaps, related-Fact qualifications and provenance traces.
- CSV and JSON facts-register downloads.
- Safe synthetic graph data, automated tests and GitHub Actions checks.

## Fastest Windows setup

Install Python 3.11, extract the ZIP, open PowerShell in the extracted folder,
and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_and_run.ps1
```

Then open <http://localhost:8501> if the browser does not open automatically.

## Manual setup

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run graph_prototype\Home.py
```

## Tests

```powershell
.\.venv\Scripts\python.exe -m pytest graph_prototype\tests -q
```

The bundled graph is demonstration data. Replace
`graph_prototype/data/prototype_graph.json` with an approved graph while keeping
the documented node and edge structure.

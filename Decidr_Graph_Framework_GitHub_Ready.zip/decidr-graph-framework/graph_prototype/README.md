# Standalone graph credibility framework and facts register

This directory is a new implementation based on the supplied organisational graph and its
explanation. It does not modify, import, or write to the existing ledger-based credibility
framework or facts register.

## Governing model

- The organisational backbone contains Person, Role, Function, Process and System.
- Documents are evidence sources.
- Facts are searchable topics and deliberately contain no value.
- Values are stored once on `FORMAL` and `OBSERVED` Document-to-Fact edges as
  `attests_value`.
- A local vector index retrieves candidate Facts.
- Deterministic code applies source, lifecycle status, date, directness, specificity,
  corroboration, independence and completeness.
- Formal and observed outcomes remain separate.
- Missing evidence produces an explicit gap, not a fabricated contradiction.

The prototype uses TF-IDF for deterministic, offline Fact retrieval. A production embedding
model can replace this retrieval component without changing the graph credibility rules.

## Run

From the repository root after running `setup_and_run.ps1`, or after installing
`requirements.txt` into a Python 3.11 environment:

```powershell
.\.venv\Scripts\python.exe -m streamlit run graph_prototype\Home.py
```

## Test

```powershell
.\.venv\Scripts\python.exe -m pytest graph_prototype\tests -q
```

## Files

- `core.py`: graph validation, retrieval and credibility reasoning.
- `register.py`: graph-native facts-register projection and exports.
- `data/prototype_graph.json`: standalone prototype graph.
- `config/credibility.json`: versioned weights and thresholds.
- `pages/`: independent Streamlit interfaces.

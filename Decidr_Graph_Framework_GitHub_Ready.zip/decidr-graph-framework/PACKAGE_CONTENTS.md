# Package contents

This repository contains the complete standalone graph prototype:

- `graph_prototype/core.py` - graph validation, retrieval and credibility rules.
- `graph_prototype/register.py` - graph facts-register projection and exports.
- `graph_prototype/Home.py` and `pages/` - Streamlit application.
- `graph_prototype/data/prototype_graph.json` - safe synthetic demonstration graph.
- `graph_prototype/config/credibility.json` - weights and thresholds.
- `graph_prototype/tests/` - automated tests.
- `.github/workflows/quality.yml` - GitHub quality checks.
- `pyproject.toml` and `requirements.txt` - Python dependencies.
- `setup_and_run.ps1` and `setup_and_run.sh` - local installation and launch scripts.

The ZIP excludes local environments, caches, secrets and generated output files.
